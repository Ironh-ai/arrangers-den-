document.addEventListener("DOMContentLoaded", function() {
    console.log("Page has loaded successfully.");

    let sheetMusicLink = document.querySelector("#sheet-music a");
    if (sheetMusicLink) {
        console.log("Sheet music link found: ", sheetMusicLink.href);
    } else {
        console.error("Sheet music link not found!");
    }
    
    let videoIframe = document.querySelector("#videos iframe");
    if (videoIframe) {
        console.log("Video iframe source: ", videoIframe.src);
    } else {
        console.error("Video iframe not found!");
    }
    
    let contactEmail = document.querySelector("#contact p");
    if (contactEmail) {
        console.log("Contact email found: ", contactEmail.textContent);
    } else {
        console.error("Contact email not found!");
    }
});
